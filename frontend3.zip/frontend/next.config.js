module.exports = {
    env: {
        API_FETCH_URL: 'https://backend-kajori-2.onrender.com',
        // API_FETCH_URL: 'http://localhost:3001',
    },
    images: {
<<<<<<< HEAD
        domains: ['backend-kajori-2.onrender.com'],
=======
       
        domains: ['backend-kajori-2.onrender.com'],
    
        // domains: ['localhost'],
>>>>>>> cf5625fd1d608d05275690f9158797830d3ae243
      },
  }
